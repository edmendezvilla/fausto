import { Component } from '@angular/core';

@Component({
  selector: 'app-components1',
  standalone: true,
  imports: [],
  templateUrl: './components1.component.html',
  styleUrl: './components1.component.css'
})
export class Components1Component {

}
