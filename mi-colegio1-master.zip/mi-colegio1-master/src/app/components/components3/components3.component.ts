import { Component } from '@angular/core';

@Component({
  selector: 'app-components3',
  standalone: true,
  imports: [],
  templateUrl: './components3.component.html',
  styleUrl: './components3.component.css'
})
export class Components3Component {

}
