import { Component } from '@angular/core';

@Component({
  selector: 'app-components4',
  standalone: true,
  imports: [],
  templateUrl: './components4.component.html',
  styleUrl: './components4.component.css'
})
export class Components4Component {

}
