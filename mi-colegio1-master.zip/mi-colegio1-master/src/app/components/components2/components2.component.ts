import { Component } from '@angular/core';

@Component({
  selector: 'app-components2',
  standalone: true,
  imports: [],
  templateUrl: './components2.component.html',
  styleUrl: './components2.component.css'
})
export class Components2Component {

}
