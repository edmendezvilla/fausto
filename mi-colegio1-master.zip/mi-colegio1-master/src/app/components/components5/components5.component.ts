import { Component } from '@angular/core';

@Component({
  selector: 'app-components5',
  standalone: true,
  imports: [],
  templateUrl: './components5.component.html',
  styleUrl: './components5.component.css'
})
export class Components5Component {

}
