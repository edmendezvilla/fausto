import { Component } from '@angular/core';

@Component({
  selector: 'app-components6',
  standalone: true,
  imports: [],
  templateUrl: './components6.component.html',
  styleUrl: './components6.component.css'
})
export class Components6Component {
  
  

}
