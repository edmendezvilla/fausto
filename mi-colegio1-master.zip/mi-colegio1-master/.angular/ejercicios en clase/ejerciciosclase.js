"use strict"

/*let plate = "PBB-8668";
let parts = plate.split("-");

alert(parts[1]);*/

/*let number = [4,5,7,10,25]
alert(number.find(num => num === 4));

function fn (item) {
    if (item.id == 1) {
        return true 
    }else{
        return false 
    }
}*/

/*let numbers = [15,18,16,21,25,27,30,40,35];
let selectd = numbers.filter(item => item > 25 && item < 40 );

alert(typeof(selectd));*/
