![Imagen de WhatsApp 2024-01-23 a las 13 11 59_0b1ed3ff](https://github.com/Mesias02/mi-colegio1/assets/146044728/61684185-fa9d-49fd-babf-7d54ce87aca4)
